package uk.hmrc.sft;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.io.IOUtils;
import org.apache.ftpserver.DataConnectionConfigurationFactory;
import org.apache.ftpserver.FtpServer;
import org.apache.ftpserver.FtpServerFactory;
import org.apache.ftpserver.config.spring.factorybeans.FtpServerFactoryBean;
import org.apache.ftpserver.ftplet.FtpException;
import org.apache.ftpserver.ftplet.Ftplet;
import org.apache.ftpserver.listener.Listener;
import org.apache.ftpserver.listener.ListenerFactory;
import org.apache.ftpserver.usermanager.ClearTextPasswordEncryptor;
import org.apache.ftpserver.usermanager.PropertiesUserManagerFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;

/**
 * Note: the class marked with @ configuration will be added to the IOC
 * container, and all methods annotated with @ bean in the class will be
 * dynamically proxied, so calling this method will return the same instance.
 * FTP service access address: ftp://localhost:3131/
 */
@Configuration("MyFtp")
public class MyFtpServer {
	private static final Logger logger = LoggerFactory.getLogger(MyFtpServer.class);
	// The data source can be directly injected after configuring the springboot
//	private DataSource dataSource;
	FtpServer server;

	// Here we use the spring feature of loading @ configuration to complete the
	// initialization of FTP server
	public MyFtpServer() {
//		this.dataSource = dataSource;
		initFtp();
		logger.info("Apache ftp server is already instantiation complete!");
	}

/**
	 * ftp server init
	 * 
	 * @throws IOException
	 */
	public void initFtp() {
		
		FtpServerFactory serverFactory = new FtpServerFactory();
		ListenerFactory factory = new ListenerFactory();

		// set the port of the listener
		factory.setPort(2221);

		// replace the default listener
		serverFactory.addListener("default", factory.createListener());
		
		  DataConnectionConfigurationFactory dataConnectionConfFactory = new DataConnectionConfigurationFactory();
		  dataConnectionConfFactory.setPassivePorts("10000-10500");
		  factory.setDataConnectionConfiguration(dataConnectionConfFactory.createDataConnectionConfiguration());

		  
		  Listener listener = factory.createListener();
		  serverFactory.addListener("default", listener);
		  //5. Configure custom user events
		  Map<String, Ftplet> ftpLets = new HashMap();
		  ftpLets.put("ftpService", new MyFtpPlet());
		  serverFactory.setFtplets(ftpLets);
		  
		  
		  PropertiesUserManagerFactory userManagerFactory = new PropertiesUserManagerFactory(); 
		  String tempPath = System.getProperty("java.io.tmpdir") + System.currentTimeMillis() +  ".properties"; File tempConfig = new File(tempPath); 
		  ClassPathResource resource = new ClassPathResource("users.properties");
		  try {
				  IOUtils.copy(resource.getInputStream(), new FileOutputStream(tempConfig)); }
				  catch (IOException e) { // TODO Auto-generated catch block
				  e.printStackTrace(); } 
		  userManagerFactory.setFile(tempConfig);
		  userManagerFactory.setPasswordEncryptor(new ClearTextPasswordEncryptor()); //
		  serverFactory.setUserManager(userManagerFactory.createUserManager());
		  
		// start the server
		FtpServer server = serverFactory.createServer();         
		try {
			server.start();
		} catch (FtpException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	}
/*
 * FtpServerFactory serverFactory = new FtpServerFactory(); ListenerFactory
 * listenerFactory = new ListenerFactory(); listenerFactory.setPort(3131);
 * DataConnectionConfigurationFactory dataConnectionConfFactory = new
 * DataConnectionConfigurationFactory();
 * dataConnectionConfFactory.setPassivePorts("10000-10500");
 * listenerFactory.setDataConnectionConfiguration(dataConnectionConfFactory.
 * createDataConnectionConfiguration()); Listener listener =
 * listenerFactory.createListener(); serverFactory.addListener("default",
 * listener); Map<String, Ftplet> ftpLets = new HashMap();
 * ftpLets.put("ftpService", new MyFtpPlet());
 * serverFactory.setFtplets(ftpLets); PropertiesUserManagerFactory
 * userManagerFactory = new PropertiesUserManagerFactory(); String tempPath =
 * System.getProperty("java.io.tmpdir") + System.currentTimeMillis() +
 * ".properties"; File tempConfig = new File(tempPath); ClassPathResource
 * resource = new ClassPathResource("users.properties"); try {
 * IOUtils.copy(resource.getInputStream(), new FileOutputStream(tempConfig)); }
 * catch (IOException e) { // TODO Auto-generated catch block
 * e.printStackTrace(); } userManagerFactory.setFile(tempConfig);
 * userManagerFactory.setPasswordEncryptor(new ClearTextPasswordEncryptor()); //
 * the password is in clear text
 * serverFactory.setUserManager(userManagerFactory.createUserManager()); server
 * = serverFactory.createServer(); }
 * 
 *//**
	 * ftp server start
	 */
/*
 * public void start() { try { server.start();
 * logger.info("Apache Ftp server is starting!"); } catch (FtpException e) {
 * e.printStackTrace(); } }
 * 
 *//**
	 * ftp server stop
	 */
/*
 * public void stop() { server.stop();
 * logger.info("Apache Ftp server is stoping!"); } }
 */