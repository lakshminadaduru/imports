package uk.hmrc.sft;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootFtpserverApplicationTests {

	@Test
	void contextLoads() {
	}

}
